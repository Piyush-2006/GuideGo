#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

uv sync --locked
PORT=25252 BASE_PATH=/ pnpm --filter @workspace/guidego run build
exec uv run --project "$ROOT" uvicorn guidego.api:app \
  --host 0.0.0.0 \
  --port "${PORT:-8000}"
