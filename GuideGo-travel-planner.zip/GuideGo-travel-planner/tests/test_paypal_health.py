import base64
import os
import unittest
from unittest.mock import patch

from fastapi import HTTPException
from fastapi.testclient import TestClient
from starlette.requests import Request

from guidego.api import (
    PAYPAL_TOKEN_HOST,
    PAYPAL_TOKEN_PATH,
    _paypal_health_rate_limit_lock,
    _paypal_health_request_times,
    app,
    paypal_health_check,
)


class FakeResponse:
    def __init__(self, status: int, body: bytes = b"") -> None:
        self.status = status
        self.body = body

    def read(self, size: int = -1) -> bytes:
        if size < 0:
            return self.body
        return self.body[:size]


class FakeHTTPSConnection:
    def __init__(self, response: FakeResponse) -> None:
        self.response = response
        self.request_args: tuple | None = None
        self.closed = False

    def request(self, *args, **kwargs) -> None:
        self.request_args = (args, kwargs)

    def getresponse(self) -> FakeResponse:
        return self.response

    def close(self) -> None:
        self.closed = True


def request_from_ip(
    client_ip: str,
    forwarded_ip: str | None = None,
    authorization: str | None = "Bearer test-health-token",
) -> Request:
    headers = []
    if forwarded_ip is not None:
        headers.append((b"x-forwarded-for", forwarded_ip.encode("ascii")))
    if authorization is not None:
        headers.append((b"authorization", authorization.encode("ascii")))
    return Request(
        {
            "type": "http",
            "asgi": {"version": "3.0"},
            "http_version": "1.1",
            "method": "GET",
            "scheme": "http",
            "path": "/api/paypal/health",
            "raw_path": b"/api/paypal/health",
            "query_string": b"",
            "headers": headers,
            "client": (client_ip, 12345),
            "server": ("testserver", 80),
        }
    )


class PayPalHealthTests(unittest.TestCase):
    def setUp(self) -> None:
        with _paypal_health_rate_limit_lock:
            _paypal_health_request_times.clear()
        self.environment_patch = patch.dict(
            os.environ,
            {"PAYPAL_HEALTH_TOKEN": "test-health-token"},
            clear=True,
        )
        self.environment_patch.start()
        self.addCleanup(self.environment_patch.stop)

    def test_route_is_registered(self) -> None:
        self.assertTrue(
            any(
                route.path == "/api/paypal/health" and "GET" in route.methods
                for route in app.routes
            )
        )

    def test_missing_credential_returns_not_configured(self) -> None:
        with (
            patch.dict(os.environ, {"PAYPAL_CLIENT_ID": "test-client-id"}),
            patch("guidego.api.http.client.HTTPSConnection") as connection_class,
        ):
            self.assertEqual(
                paypal_health_check(request_from_ip("198.51.100.1")),
                {"paypal": "not_configured"},
            )
            connection_class.assert_not_called()

    def test_missing_health_token_configuration_fails_closed(self) -> None:
        with (
            patch.dict(os.environ, {}, clear=True),
            patch("guidego.api.http.client.HTTPSConnection") as connection_class,
        ):
            with self.assertRaises(HTTPException) as raised:
                paypal_health_check(request_from_ip("203.0.113.14"))

        self.assertEqual(raised.exception.status_code, 503)
        connection_class.assert_not_called()

    def test_missing_or_invalid_bearer_token_is_rejected_before_paypal(self) -> None:
        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
            ),
            patch("guidego.api.http.client.HTTPSConnection") as connection_class,
        ):
            for authorization in (
                None,
                "Bearer wrong-token",
                "Basic test-health-token",
            ):
                with self.subTest(authorization=authorization):
                    with self.assertRaises(HTTPException) as raised:
                        paypal_health_check(
                            request_from_ip(
                                "203.0.113.15",
                                authorization=authorization,
                            )
                        )
                    self.assertEqual(raised.exception.status_code, 401)
                    self.assertEqual(
                        raised.exception.headers["WWW-Authenticate"],
                        "Bearer",
                    )

        connection_class.assert_not_called()

    def test_http_route_rejects_missing_or_invalid_bearer_before_paypal(
        self,
    ) -> None:
        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
            ),
            patch("guidego.api.http.client.HTTPSConnection") as connection_class,
        ):
            client = TestClient(app)
            try:
                for headers in ({}, {"Authorization": "Bearer wrong-token"}):
                    with self.subTest(headers=headers):
                        response = client.get(
                            "/api/paypal/health",
                            headers=headers,
                        )
                        self.assertEqual(response.status_code, 401)
                        self.assertEqual(
                            response.headers.get("www-authenticate"),
                            "Bearer",
                        )
                        self.assertEqual(
                            response.json(),
                            {"detail": "Unauthorized"},
                        )
            finally:
                client.close()

        connection_class.assert_not_called()

    def test_http_route_authorized_response_contains_only_safe_status(
        self,
    ) -> None:
        connection = FakeHTTPSConnection(
            FakeResponse(
                200,
                b'{"access_token":"test-access-token","token_type":"Bearer"}',
            )
        )
        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
            ),
            patch(
                "guidego.api.http.client.HTTPSConnection",
                return_value=connection,
            ) as connection_class,
        ):
            client = TestClient(app)
            try:
                response = client.get(
                    "/api/paypal/health",
                    headers={"Authorization": "Bearer test-health-token"},
                )
            finally:
                client.close()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"paypal": "connected"})
        self.assertNotIn("test-access-token", response.text)
        connection_class.assert_called_once_with(PAYPAL_TOKEN_HOST, timeout=15)

    def test_success_posts_basic_auth_and_returns_only_safe_status(self) -> None:
        response = FakeResponse(
            200,
            b'{"access_token":"test-access-token","token_type":"Bearer"}',
        )
        connection = FakeHTTPSConnection(response)

        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
                clear=False,
            ),
            patch(
                "guidego.api.http.client.HTTPSConnection",
                return_value=connection,
            ) as connection_class,
        ):
            result = paypal_health_check(request_from_ip("198.51.100.2"))

        self.assertEqual(result, {"paypal": "connected"})
        connection_class.assert_called_once_with(PAYPAL_TOKEN_HOST, timeout=15)
        args, kwargs = connection.request_args
        self.assertEqual(args[:2], ("POST", PAYPAL_TOKEN_PATH))
        self.assertEqual(kwargs["body"], b"grant_type=client_credentials")
        self.assertEqual(
            kwargs["headers"]["Authorization"],
            "Basic "
            + base64.b64encode(b"test-client-id:test-client-secret").decode(
                "ascii"
            ),
        )
        self.assertEqual(
            kwargs["headers"]["Content-Type"],
            "application/x-www-form-urlencoded",
        )
        self.assertNotIn("test-access-token", str(result))
        self.assertTrue(connection.closed)

    def test_rejected_credentials_return_authentication_failed(self) -> None:
        connection = FakeHTTPSConnection(FakeResponse(401))
        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
                clear=False,
            ),
            patch(
                "guidego.api.http.client.HTTPSConnection",
                return_value=connection,
            ),
        ):
            self.assertEqual(
                paypal_health_check(request_from_ip("198.51.100.3")),
                {"paypal": "authentication_failed"},
            )

    def test_invalid_client_error_returns_authentication_failed(self) -> None:
        connection = FakeHTTPSConnection(
            FakeResponse(400, b'{"error":"invalid_client"}')
        )
        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
                clear=False,
            ),
            patch(
                "guidego.api.http.client.HTTPSConnection",
                return_value=connection,
            ),
        ):
            self.assertEqual(
                paypal_health_check(request_from_ip("198.51.100.4")),
                {"paypal": "authentication_failed"},
            )

    def test_unexpected_response_returns_unavailable(self) -> None:
        connection = FakeHTTPSConnection(FakeResponse(500))
        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
                clear=False,
            ),
            patch(
                "guidego.api.http.client.HTTPSConnection",
                return_value=connection,
            ),
        ):
            self.assertEqual(
                paypal_health_check(request_from_ip("198.51.100.5")),
                {"paypal": "unavailable"},
            )

    def test_network_error_returns_unavailable(self) -> None:
        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
                clear=False,
            ),
            patch(
                "guidego.api.http.client.HTTPSConnection",
                side_effect=OSError("simulated connection failure"),
            ),
        ):
            self.assertEqual(
                paypal_health_check(request_from_ip("198.51.100.6")),
                {"paypal": "unavailable"},
            )

    def test_rate_limit_rejects_sixth_request_per_ip(self) -> None:
        connection = FakeHTTPSConnection(
            FakeResponse(200, b'{"access_token":"test-access-token"}')
        )
        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
                clear=False,
            ),
            patch(
                "guidego.api.http.client.HTTPSConnection",
                return_value=connection,
            ) as connection_class,
        ):
            for _ in range(5):
                self.assertEqual(
                    paypal_health_check(request_from_ip("203.0.113.10")),
                    {"paypal": "connected"},
                )

            with self.assertRaises(HTTPException) as raised:
                paypal_health_check(request_from_ip("203.0.113.10"))

        self.assertEqual(raised.exception.status_code, 429)
        self.assertEqual(connection_class.call_count, 5)

    def test_rate_limit_is_per_peer_and_ignores_forwarded_headers(self) -> None:
        connection = FakeHTTPSConnection(
            FakeResponse(200, b'{"access_token":"test-access-token"}')
        )
        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
                clear=False,
            ),
            patch(
                "guidego.api.http.client.HTTPSConnection",
                return_value=connection,
            ),
        ):
            for forwarded_ip in (
                "192.0.2.1",
                "192.0.2.2",
                "192.0.2.3",
                "192.0.2.4",
                "192.0.2.5",
            ):
                self.assertEqual(
                    paypal_health_check(
                        request_from_ip(
                            "203.0.113.11",
                            forwarded_ip=forwarded_ip,
                        )
                    ),
                    {"paypal": "connected"},
                )

            with self.assertRaises(HTTPException) as raised:
                paypal_health_check(
                    request_from_ip(
                        "203.0.113.11",
                        forwarded_ip="192.0.2.6",
                    )
                )

            self.assertEqual(
                paypal_health_check(
                    request_from_ip(
                        "203.0.113.12",
                        forwarded_ip="192.0.2.6",
                    )
                ),
                {"paypal": "connected"},
            )

        self.assertEqual(raised.exception.status_code, 429)

    def test_rate_limit_window_expires_after_one_minute(self) -> None:
        connection = FakeHTTPSConnection(
            FakeResponse(200, b'{"access_token":"test-access-token"}')
        )
        times = iter((0, 1, 2, 3, 4, 5, 60))
        with (
            patch.dict(
                os.environ,
                {
                    "PAYPAL_CLIENT_ID": "test-client-id",
                    "PAYPAL_CLIENT_SECRET": "test-client-secret",
                },
                clear=False,
            ),
            patch("guidego.api.monotonic", side_effect=lambda: next(times)),
            patch(
                "guidego.api.http.client.HTTPSConnection",
                return_value=connection,
            ),
        ):
            for _ in range(5):
                paypal_health_check(request_from_ip("203.0.113.13"))

            with self.assertRaises(HTTPException) as raised:
                paypal_health_check(request_from_ip("203.0.113.13"))
            self.assertEqual(raised.exception.status_code, 429)

            self.assertEqual(
                paypal_health_check(request_from_ip("203.0.113.13")),
                {"paypal": "connected"},
            )


if __name__ == "__main__":
    unittest.main()
