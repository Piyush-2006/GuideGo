import { useEffect, useMemo, useState } from 'react';
import {
  ArrowDownRight,
  ArrowRight,
  Compass,
  MapPin,
  RotateCw,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  UsersRound,
  Languages,
  BadgeInfo,
} from 'lucide-react';
import {
  getGetGuidesQueryKey,
  useGetGuideSummary,
  useGetGuides,
  useHealthCheck,
} from '@workspace/api-client-react';

const portraitTones = [
  'from-[#dce8df] to-[#b7d0c1] text-[#22584e]',
  'from-[#f1dfca] to-[#e4bda3] text-[#744332]',
  'from-[#d6e3e8] to-[#a7c6ce] text-[#315768]',
  'from-[#e9e0ca] to-[#d1c49b] text-[#625627]',
];

function initials(name: string) {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('');
}

function CatalogSkeleton() {
  return (
    <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3" aria-label="Loading guide profiles">
      {[0, 1, 2, 3, 4, 5].map((item) => (
        <div key={item} className="animate-pulse rounded-[1.35rem] border border-border/80 bg-card p-6">
          <div className="mb-6 flex items-center gap-4">
            <div className="h-14 w-14 rounded-2xl bg-secondary" />
            <div className="flex-1 space-y-2">
              <div className="h-4 w-2/3 rounded bg-secondary" />
              <div className="h-3 w-1/3 rounded bg-secondary" />
            </div>
          </div>
          <div className="mb-3 h-3 w-full rounded bg-secondary" />
          <div className="mb-7 h-3 w-4/5 rounded bg-secondary" />
          <div className="h-20 rounded-xl bg-secondary/75" />
        </div>
      ))}
    </div>
  );
}

export default function GuideCatalog() {
  const [city, setCity] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    const timer = window.setTimeout(() => setSearch(searchInput.trim()), 280);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  const params = useMemo(
    () => ({
      ...(city ? { city } : {}),
      ...(specialty ? { specialty } : {}),
      ...(search ? { search } : {}),
    }),
    [city, specialty, search],
  );

  const guidesQuery = useGetGuides(params, {
    query: { queryKey: getGetGuidesQueryKey(params) },
  });
  const facetsQuery = useGetGuides();
  const summaryQuery = useGetGuideSummary();
  const healthQuery = useHealthCheck();

  const guides = guidesQuery.data;
  const allGuides = facetsQuery.data;
  const summary = summaryQuery.data;
  const cities = summary?.destinations ?? [];
  const specialties = useMemo(
    () => Array.from(new Set((allGuides ?? []).flatMap((guide) => guide.specialties))).sort((a, b) => a.localeCompare(b)),
    [allGuides],
  );
  const activeFilterCount = Number(Boolean(city)) + Number(Boolean(specialty)) + Number(Boolean(searchInput.trim()));

  function clearFilters() {
    setCity('');
    setSpecialty('');
    setSearchInput('');
  }

  return (
    <main className="guidego-shell min-h-[100dvh] text-foreground">
      <div className="mx-auto max-w-[1440px] px-5 pb-16 sm:px-8 lg:px-12">
        <header className="flex h-[76px] items-center justify-between border-b border-foreground/10">
          <a href="/" className="group flex items-center gap-2.5" aria-label="GuideGo home">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-transform group-hover:-rotate-6">
              <Compass size={19} strokeWidth={1.8} />
            </span>
            <span className="font-serif text-[1.35rem] font-semibold tracking-[-0.04em]">guidego</span>
            <span className="ml-1 hidden rounded-full border border-primary/20 bg-primary/5 px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.16em] text-primary sm:inline-flex">
              Field notes
            </span>
          </a>
          <div className="flex items-center gap-2 rounded-full border border-foreground/10 bg-card/70 px-3 py-2 text-[11px] font-medium text-muted-foreground">
            <span className={`h-1.5 w-1.5 rounded-full ${healthQuery.isError ? 'bg-destructive' : healthQuery.data ? 'bg-primary' : 'bg-accent'}`} />
            <span data-testid="status-api-health">
              {healthQuery.isError ? 'Catalog connection issue' : healthQuery.data ? 'Catalog online' : 'Checking catalog'}
            </span>
          </div>
        </header>

        <section className="relative overflow-hidden pb-10 pt-12 sm:pb-14 sm:pt-[4.5rem]">
          <div className="guidego-hero-grid pointer-events-none absolute -right-12 -top-2 h-[320px] w-[48%] opacity-60" />
          <div className="relative grid gap-8 lg:grid-cols-[1fr_320px] lg:items-end">
            <div className="page-enter max-w-[780px]">
              <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-3 py-1.5 font-mono text-[10px] uppercase tracking-[.14em] text-[#8d4e35]">
                <Sparkles size={12} />
                Your first stop, somewhere new
              </div>
              <h1 className="font-serif text-[clamp(3.2rem,8vw,6.6rem)] leading-[.91] tracking-[-.065em] text-[#203c43]">
                Meet the city
                <br />
                <span className="italic text-primary">before you go.</span>
              </h1>
              <p className="mt-6 max-w-[530px] text-base leading-7 text-muted-foreground sm:text-lg">
                A starting point for getting to know a place through the people who call it home.
                Browse our fictional local guide profiles by city and specialty.
              </p>
            </div>
            <aside className="relative flex items-center gap-4 border-l-2 border-accent/65 py-1 pl-5 lg:mb-2 lg:justify-self-end">
              <div className="max-w-[210px]">
                <p className="font-mono text-[10px] uppercase tracking-[.14em] text-muted-foreground">A note on this catalog</p>
                <p className="mt-2 text-sm leading-5 text-foreground/80">
                  Every profile is fictional demo data. No guides are available for booking.
                </p>
              </div>
              <ArrowDownRight className="hidden text-accent sm:block" size={24} strokeWidth={1.4} />
            </aside>
          </div>
        </section>

        <section aria-label="Guide catalog overview" className="mb-9">
          {summaryQuery.isLoading ? (
            <div className="grid gap-px overflow-hidden rounded-2xl border border-border/80 bg-border sm:grid-cols-3">
              {[0, 1, 2].map((item) => <div key={item} className="h-[92px] animate-pulse bg-card/80" />)}
            </div>
          ) : summaryQuery.isError ? (
            <div className="flex flex-col gap-3 rounded-2xl border border-destructive/25 bg-destructive/5 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="font-semibold">Catalog overview could not load</p>
                <p className="mt-1 text-sm text-muted-foreground">The guide list may still be available below. Try loading the overview again.</p>
              </div>
              <button type="button" onClick={() => summaryQuery.refetch()} data-testid="button-retry-summary" className="inline-flex items-center gap-2 self-start rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold transition-colors hover:bg-secondary sm:self-auto">
                <RotateCw size={14} /> Retry overview
              </button>
            </div>
          ) : summary ? (
            <div className="grid overflow-hidden rounded-2xl border border-border/80 bg-card/80 sm:grid-cols-[.8fr_.8fr_1.15fr]">
              <div className="flex items-center gap-4 border-b border-border/80 px-5 py-4 sm:border-b-0 sm:border-r sm:px-6">
                <UsersRound className="text-primary" size={19} strokeWidth={1.7} />
                <div><p className="font-serif text-[1.65rem] leading-none">{summary.total_guides}</p><p className="mt-1 text-xs text-muted-foreground">fictional guides</p></div>
              </div>
              <div className="flex items-center gap-4 border-b border-border/80 px-5 py-4 sm:border-b-0 sm:border-r sm:px-6">
                <ShieldCheck className="text-primary" size={19} strokeWidth={1.7} />
                <div><p className="font-serif text-[1.65rem] leading-none">{summary.verified_guides}</p><p className="mt-1 text-xs text-muted-foreground">marked verified</p></div>
              </div>
              <div className="flex items-center justify-between gap-4 px-5 py-4 sm:px-6">
                <div className="flex items-center gap-4">
                  <MapPin className="text-accent" size={19} strokeWidth={1.7} />
                  <div><p className="font-serif text-[1.65rem] leading-none">{summary.destination_count}</p><p className="mt-1 text-xs text-muted-foreground">cities to explore</p></div>
                </div>
                {summary.destinations.length > 0 && (
                  <div className="hidden max-w-[52%] flex-wrap justify-end gap-1.5 md:flex">
                    {summary.destinations.slice(0, 4).map((destination) => (
                      <span key={destination.city} className="rounded-full bg-secondary px-2.5 py-1 text-[10px] text-secondary-foreground">
                        {destination.city}
                      </span>
                    ))}
                    {summary.destinations.length > 4 && <span className="px-1 py-1 text-[10px] text-muted-foreground">+{summary.destinations.length - 4}</span>}
                  </div>
                )}
              </div>
            </div>
          ) : null}
        </section>

        <section aria-labelledby="catalog-heading" className="scroll-mt-6">
          <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
            <div>
              <p className="mb-1 font-mono text-[10px] uppercase tracking-[.16em] text-primary">The demo directory</p>
              <h2 id="catalog-heading" className="font-serif text-3xl tracking-[-.04em] sm:text-[2.45rem]">Find your kind of local</h2>
            </div>
            <p className="text-sm text-muted-foreground">
              {guidesQuery.isLoading ? 'Finding profiles…' : guidesQuery.isError ? 'Guide results unavailable' : `${guides?.length ?? 0} ${guides?.length === 1 ? 'profile' : 'profiles'} shown`}
            </p>
          </div>

          <div className="mb-7 grid gap-3 rounded-2xl border border-border/80 bg-card/85 p-3 sm:grid-cols-2 lg:grid-cols-[1fr_220px_220px_auto] lg:items-center lg:p-3.5">
            <label className="relative block sm:col-span-2 lg:col-span-1">
              <span className="sr-only">Search guide profiles</span>
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={17} />
              <input
                type="search"
                value={searchInput}
                onChange={(event) => setSearchInput(event.target.value)}
                placeholder="Search names, languages, specialties…"
                data-testid="input-guide-search"
                className="h-12 w-full rounded-xl border border-border/80 bg-background/75 pl-11 pr-4 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/10"
              />
            </label>
            <label className="block">
              <span className="sr-only">Filter by city</span>
              <select value={city} onChange={(event) => setCity(event.target.value)} data-testid="select-city-filter" className="h-12 w-full appearance-none rounded-xl border border-border/80 bg-background/75 px-4 text-sm text-foreground outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/10">
                <option value="">All cities</option>
                {cities.map((destination) => <option key={destination.city} value={destination.city}>{destination.city} · {destination.guide_count}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="sr-only">Filter by specialty</span>
              <select value={specialty} onChange={(event) => setSpecialty(event.target.value)} data-testid="select-specialty-filter" className="h-12 w-full appearance-none rounded-xl border border-border/80 bg-background/75 px-4 text-sm text-foreground outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/10">
                <option value="">All specialties</option>
                {specialties.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </label>
            {activeFilterCount > 0 ? (
              <button type="button" onClick={clearFilters} data-testid="button-clear-filters" className="h-12 rounded-xl px-4 text-sm font-semibold text-primary transition-colors hover:bg-primary/5">
                Clear filters
              </button>
            ) : (
              <span className="hidden items-center justify-center gap-1.5 px-3 text-[11px] text-muted-foreground lg:flex"><span className="h-1.5 w-1.5 rounded-full bg-primary" /> Browse the directory</span>
            )}
          </div>

          {guidesQuery.isLoading ? (
            <CatalogSkeleton />
          ) : guidesQuery.isError ? (
            <div className="rounded-[1.5rem] border border-destructive/25 bg-card px-6 py-12 text-center sm:py-16">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-destructive/10 text-destructive"><BadgeInfo size={22} /></div>
              <h3 className="mt-4 font-serif text-2xl">We couldn't reach the guide catalog</h3>
              <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-muted-foreground">The profiles come from the GuideGo API, which is currently unavailable. Please try again in a moment.</p>
              <button type="button" onClick={() => guidesQuery.refetch()} data-testid="button-retry-guides" className="mt-5 inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition hover:brightness-110">
                <RotateCw size={15} /> Retry catalog
              </button>
            </div>
          ) : guides && guides.length === 0 ? (
            <div className="rounded-[1.5rem] border border-border/80 bg-card/80 px-6 py-12 text-center sm:py-16">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-primary"><Search size={21} /></div>
              <h3 className="mt-4 font-serif text-2xl">No profiles match those filters</h3>
              <p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted-foreground">Try another city or specialty, or clear your search to see the full demo directory.</p>
              <button type="button" onClick={clearFilters} data-testid="button-reset-empty-filters" className="mt-5 rounded-full border border-primary/30 px-5 py-2.5 text-sm font-semibold text-primary transition hover:bg-primary/5">Show all profiles</button>
            </div>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {guides?.map((guide, index) => (
                <article key={guide.id} data-testid={`card-guide-${guide.id}`} className="guide-card stagger-in flex flex-col rounded-[1.35rem] border border-border/80 bg-card p-5 sm:p-6" style={{ animationDelay: `${Math.min(index, 7) * 55}ms` }}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-3.5">
                      <div className={`flex h-[58px] w-[58px] shrink-0 items-center justify-center rounded-[19px] bg-gradient-to-br ${portraitTones[index % portraitTones.length]} font-serif text-xl font-semibold tracking-[-.04em]`}>
                        {initials(guide.name)}
                      </div>
                      <div className="min-w-0">
                        <h3 data-testid={`text-guide-name-${guide.id}`} className="truncate font-serif text-[1.3rem] font-semibold leading-tight tracking-[-.035em]">{guide.name}</h3>
                        <p className="mt-1 flex items-center gap-1 text-[12px] text-muted-foreground"><MapPin size={12} className="text-accent" />{guide.city}</p>
                      </div>
                    </div>
                    {guide.verified ? (
                      <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-primary/8 px-2.5 py-1 text-[10px] font-semibold text-primary"><ShieldCheck size={12} /> Demo verified</span>
                    ) : (
                      <span className="shrink-0 rounded-full bg-secondary px-2.5 py-1 text-[10px] font-medium text-secondary-foreground">Not verified</span>
                    )}
                  </div>

                  <div className="mt-5 flex flex-wrap gap-1.5">
                    {guide.specialties.map((item) => <span key={item} className="rounded-full border border-primary/15 bg-primary/[.045] px-2.5 py-1 text-[11px] font-medium text-primary">{item}</span>)}
                  </div>

                  <div className="mt-5 flex items-start gap-2 border-t border-border/70 pt-4">
                    <Languages size={15} className="mt-0.5 shrink-0 text-muted-foreground" />
                    <p className="text-xs leading-5 text-muted-foreground">{guide.languages.join(' · ')}</p>
                  </div>

                  <div className="mt-auto pt-5">
                    <div className="flex items-center justify-between border-t border-border/70 pt-4">
                      <div className="flex items-center gap-1.5 text-sm">
                        <Star size={14} className="fill-accent text-accent" />
                        <span data-testid={`text-guide-rating-${guide.id}`} className="font-semibold">{guide.rating}</span>
                        <span className="text-[11px] text-muted-foreground">demo rating</span>
                      </div>
                      <p className="text-right">
                        <span data-testid={`text-guide-price-${guide.id}`} className="font-mono text-[15px] font-medium">${guide.price_per_day_usd}</span>
                        <span className="ml-1 text-[11px] text-muted-foreground">/ day</span>
                      </p>
                    </div>
                    <div className="mt-4 flex items-center justify-between gap-2 rounded-xl bg-[#f3eee3] px-3 py-2.5 text-[10px] text-[#6b675a]">
                      <span className="font-mono uppercase tracking-[.1em]">Fictional demo profile</span>
                      <span className="shrink-0">API demo flag: {guide.is_demo ? 'yes' : 'no'}</span>
                      <span className="font-mono">ID {guide.id}</span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>

        <footer className="mt-14 flex flex-col gap-3 border-t border-foreground/10 pt-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>GuideGo · A directory of fictional local guide profiles</p>
          <p className="inline-flex items-center gap-1.5">A practical place to begin <ArrowRight size={13} className="text-primary" /></p>
        </footer>
      </div>
    </main>
  );
}
