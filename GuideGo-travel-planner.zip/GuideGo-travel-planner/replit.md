# GuideGo

GuideGo is an AI travel agent that plans trips, books fictional demo guides, and uses sandbox-only PayPal flows for the PayPal AI Hackathon.

## Run & Operate

- `pnpm run guidego` — build the frontend and start the local FastAPI app (after one-time dependency setup)
- Replit preview workflows: `artifacts/guidego: web` and `artifacts/api-server: API Server`
- `pnpm --filter @workspace/api-spec run codegen` — regenerate typed API hooks from OpenAPI
- `pnpm --filter @workspace/guidego run typecheck` — check the frontend
- `pnpm run typecheck` — check workspace TypeScript packages

## Stack

- Frontend: React + Vite in `artifacts/guidego`
- Backend: Python + FastAPI in `guidego/`
- Database: SQLite; `GUIDEGO_DATABASE_PATH` can override its local file path
- API contract: `lib/api-spec/openapi.yaml`, with generated TypeScript hooks in `lib/api-client-react`
- AI: OpenAI-compatible API; read `LLM_BASE_URL`, `LLM_API_KEY`, and `LLM_MODEL` from Replit Secrets
- Payments: PayPal REST API in sandbox only; read `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` from Replit Secrets

## Product Requirements

- Build in the order from the user's GuideGo brief: demo guides, AI itinerary and guide selection, PayPal authorization, guide confirmation/capture or decline/void, disruption handling, payout, then booking history.
- The guide records are fictional. Clearly identify them as demo data; demo verification is not a real identity or credential check.
- Use PayPal Orders v2 with `AUTHORIZE`; capture only after guide confirmation and void if declined/cancelled. Do not use live PayPal credentials or endpoints.
- If PayPal Payouts are unavailable in sandbox, store a clearly marked simulated payout; never present it as a real transfer.
- Show payment, LLM, and itinerary/disruption errors in the UI and record relevant steps in the activity log.
- Never put API keys in source files or ask the user to paste them into chat. Use Replit Secrets.
- Keep the app runnable from README instructions and prepare it for Render deployment.

## Current Milestone

Step 1 is implemented: a SQLite guide catalog with 12 fictional profiles across Manali, Jaipur, and Kochi, plus a responsive React catalog with real API filters. AI planning, PayPal, bookings, and payouts are not implemented yet.

## Pointers

- `guidego/seeds.py` — fictional demo guide profiles
- `guidego/database.py` — SQLite schema, seeding, catalog queries
- `guidego/api.py` — FastAPI routes
- `README.md` — setup, current milestone test checklist, and integration status
- `LICENSE` — MIT license
