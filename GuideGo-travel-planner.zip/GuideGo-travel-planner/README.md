# GuideGo

GuideGo is an AI-assisted travel planner for building a trip, finding a local guide, and managing booking changes. The current milestone implements the guide catalog and its SQLite demo data.

## Current milestone

- 12 fictional guide profiles across Manali, Jaipur, and Kochi
- SQLite-backed guide catalog with language, specialty, daily USD price, rating, verification-status, and demo-data fields
- FastAPI endpoints for listing/filtering guides and summarizing the catalog
- React catalog screen with city, specialty, and text filters

**Every seeded profile is fictional. The `verified` field is illustrative demo state only; it does not represent a real person or a real verification check.**

## Run locally

Requirements: Python 3.13+, `uv`, Node.js, and pnpm.

One-time setup:

```sh
pnpm install
uv sync --locked
```

Start the built app with one command:

```sh
pnpm run guidego
```

Then open `http://localhost:8000`. The command builds the React page and starts FastAPI, which serves both the app and API. The Replit preview runs the frontend and API as managed services.

## Step 1 test checklist

1. Start the app and confirm the catalog shows 12 fictional demo guides.
2. Filter by each destination; Manali, Jaipur, and Kochi should each show four guides.
3. Filter by a specialty such as `Trekking`, then clear filters and search for a name such as `Naina Sharma`.
4. Confirm the demo-data notice remains visible and the cards show language, specialties, daily price, rating, and the illustrative verification status.

API checks:

```sh
curl http://localhost:8000/api/healthz
curl http://localhost:8000/api/guides
curl 'http://localhost:8000/api/guides?city=Manali&specialty=Trekking'
curl http://localhost:8000/api/guide-summary
```

The SQLite database is created at `data/guidego.sqlite3` on first start. Set `GUIDEGO_DATABASE_PATH` to use another location. Seed insertion is safe to repeat; it does not duplicate the 12 stable demo records.

## How AI and PayPal are used

AI planning and PayPal checkout are **not implemented in this first milestone**. No API keys are needed to run the guide catalog, and it does not create bookings or move money.

In the later milestones, the AI provider will use the OpenAI-compatible `LLM_BASE_URL`, `LLM_API_KEY`, and `LLM_MODEL` settings. PayPal will use sandbox-only credentials (`PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET`) and an authorize-first flow. Add those values through Replit Secrets when those integrations are built; do not put credentials in source files.

## Project layout

- `guidego/` — FastAPI app, SQLite access, API schemas, and fictional seed profiles
- `artifacts/guidego/` — React + Vite web app
- `lib/api-spec/openapi.yaml` — API contract used to generate typed frontend hooks
- `data/guidego.sqlite3` — local SQLite database, created at runtime and excluded from Git

## License

This project is licensed under the MIT License; see [LICENSE](LICENSE).
