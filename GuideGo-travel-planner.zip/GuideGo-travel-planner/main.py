"""FastAPI entry point for GuideGo."""

from guidego.api import app
