from pydantic import BaseModel, ConfigDict, Field


class Guide(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    name: str
    city: str
    languages: list[str]
    specialties: list[str]
    price_per_day_usd: int = Field(gt=0)
    rating: float = Field(ge=0, le=5)
    verified: bool
    is_demo: bool


class DestinationSummary(BaseModel):
    city: str
    guide_count: int


class GuideSummary(BaseModel):
    total_guides: int
    verified_guides: int
    destination_count: int
    destinations: list[DestinationSummary]
from datetime import date
from pydantic import BaseModel, ConfigDict, Field


class CreateBookingRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    guide_id: str = Field(min_length=1, max_length=100)
    start_date: date
    days: int = Field(ge=1, le=30)
    idempotency_key: str = Field(min_length=16, max_length=100)