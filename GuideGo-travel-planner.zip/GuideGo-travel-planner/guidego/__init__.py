"""GuideGo application package."""
