from contextlib import asynccontextmanager
import base64
from collections import deque
import http.client
import hmac
import json
import os
from pathlib import Path
from threading import Lock
from time import monotonic
from urllib.parse import urlencode

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles

from guidego.database import (
    get_guide_summary,
    get_booking,
    initialize_database,
    list_guides,
    reserve_booking,
    transition_booking,
)
from guidego.schemas import Guide, GuideSummary

@asynccontextmanager
async def lifespan(_: FastAPI):
    initialize_database()
    yield


app = FastAPI(
    title="GuideGo API",
    description="Guide catalog API; all seeded guide data is fictional demo data.",
    version="0.1.0",
    docs_url=None,
    redoc_url=None,
    lifespan=lifespan,
)


@app.get("/api/healthz", tags=["health"])
def health_check() -> dict[str, str]:
    return {"status": "ok"}


PAYPAL_TOKEN_HOST = "api-m.sandbox.paypal.com"
PAYPAL_TOKEN_PATH = "/v1/oauth2/token"
PAYPAL_RESPONSE_LIMIT = 65_536
PAYPAL_HEALTH_RATE_LIMIT = 5
PAYPAL_HEALTH_RATE_WINDOW_SECONDS = 60.0
_paypal_health_request_times: dict[str, deque[float]] = {}
_paypal_health_rate_limit_lock = Lock()


def _authorize_paypal_health_request(request: Request) -> None:
    configured_token = os.environ.get("PAYPAL_HEALTH_TOKEN")
    if not configured_token:
        raise HTTPException(
            status_code=503,
            detail="Health check authorization is not configured",
        )

    authorization = request.headers.get("authorization", "")
    scheme, separator, supplied_token = authorization.partition(" ")
    if (
        not separator
        or scheme.lower() != "bearer"
        or not hmac.compare_digest(
            supplied_token.encode("utf-8"),
            configured_token.encode("utf-8"),
        )
    ):
        raise HTTPException(
            status_code=401,
            detail="Unauthorized",
            headers={"WWW-Authenticate": "Bearer"},
        )


def _allow_paypal_health_request(client_ip: str) -> bool:
    now = monotonic()
    window_start = now - PAYPAL_HEALTH_RATE_WINDOW_SECONDS

    with _paypal_health_rate_limit_lock:
        for ip, request_times in list(_paypal_health_request_times.items()):
            while request_times and request_times[0] <= window_start:
                request_times.popleft()
            if not request_times:
                del _paypal_health_request_times[ip]

        request_times = _paypal_health_request_times.setdefault(
            client_ip, deque()
        )
        if len(request_times) >= PAYPAL_HEALTH_RATE_LIMIT:
            return False

        request_times.append(now)
        return True


def _paypal_error_code(response_body: bytes) -> str | None:
    try:
        payload = json.loads(response_body)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None

    if isinstance(payload, dict) and isinstance(payload.get("error"), str):
        return payload["error"]
    return None


@app.get("/api/paypal/health", tags=["health"])
def paypal_health_check(request: Request) -> dict[str, str]:
    _authorize_paypal_health_request(request)

    # Use the ASGI peer address, not a caller-supplied forwarding header.
    client_ip = request.client.host if request.client else "unknown"
    if not _allow_paypal_health_request(client_ip):
        raise HTTPException(status_code=429, detail="Rate limit exceeded")

    try:
        client_id = os.environ["PAYPAL_CLIENT_ID"]
        client_secret = os.environ["PAYPAL_CLIENT_SECRET"]
    except KeyError:
        return {"paypal": "not_configured"}

    basic_credentials = base64.b64encode(
        f"{client_id}:{client_secret}".encode("utf-8")
    ).decode("ascii")
    connection: http.client.HTTPSConnection | None = None

    try:
        connection = http.client.HTTPSConnection(PAYPAL_TOKEN_HOST, timeout=15)
        connection.request(
            "POST",
            PAYPAL_TOKEN_PATH,
            body=urlencode({"grant_type": "client_credentials"}).encode("ascii"),
            headers={
                "Authorization": f"Basic {basic_credentials}",
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            },
        )
        response = connection.getresponse()

        if response.status in (401, 403):
            return {"paypal": "authentication_failed"}

        if response.status == 400:
            response_body = response.read(PAYPAL_RESPONSE_LIMIT + 1)
            if (
                len(response_body) <= PAYPAL_RESPONSE_LIMIT
                and _paypal_error_code(response_body) == "invalid_client"
            ):
                return {"paypal": "authentication_failed"}
            return {"paypal": "unavailable"}

        if response.status != 200:
            return {"paypal": "unavailable"}

        response_body = response.read(PAYPAL_RESPONSE_LIMIT + 1)
        if len(response_body) > PAYPAL_RESPONSE_LIMIT:
            return {"paypal": "unavailable"}

        try:
            payload = json.loads(response_body)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {"paypal": "unavailable"}

        if (
            isinstance(payload, dict)
            and isinstance(payload.get("access_token"), str)
            and payload["access_token"]
        ):
            return {"paypal": "connected"}
        return {"paypal": "unavailable"}
    except (http.client.HTTPException, OSError, TimeoutError, ValueError):
        return {"paypal": "unavailable"}
    finally:
        if connection is not None:
            try:
                connection.close()
            except OSError:
                pass


@app.get("/api/guides", response_model=list[Guide], tags=["guides"])
def guides(
    city: str | None = Query(default=None, max_length=80),
    specialty: str | None = Query(default=None, max_length=80),
    search: str | None = Query(default=None, max_length=120),
) -> list[dict]:
    return list_guides(city=city, specialty=specialty, search=search)


@app.get("/api/guide-summary", response_model=GuideSummary, tags=["guides"])
def guide_summary() -> dict:
    return get_guide_summary()


PROJECT_ROOT = Path(__file__).resolve().parents[1]
FRONTEND_DIST = PROJECT_ROOT / "artifacts" / "guidego" / "dist" / "public"

if FRONTEND_DIST.is_dir():
    assets_directory = FRONTEND_DIST / "assets"
    if assets_directory.is_dir():
        app.mount(
            "/assets",
            StaticFiles(directory=assets_directory),
            name="guidego-assets",
        )

    @app.get("/", include_in_schema=False)
    def frontend_index() -> FileResponse:
        return FileResponse(FRONTEND_DIST / "index.html")

    @app.get("/{path:path}", include_in_schema=False)
    def frontend_routes(path: str) -> Response:
        if path.startswith("api/"):
            return PlainTextResponse("Not found", status_code=404)
        return FileResponse(FRONTEND_DIST / "index.html")
