from __future__ import annotations

import json
import os
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from guidego.seeds import DEMO_GUIDES


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATABASE_PATH = PROJECT_ROOT / "data" / "guidego.sqlite3"
DATABASE_PATH = Path(os.environ.get("GUIDEGO_DATABASE_PATH", DEFAULT_DATABASE_PATH))


def connect() -> sqlite3.Connection:
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 5000")
    return connection


def initialize_database() -> None:
    with closing(connect()) as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS guides (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                city TEXT NOT NULL,
                languages_json TEXT NOT NULL,
                specialties_json TEXT NOT NULL,
                price_per_day_usd INTEGER NOT NULL CHECK (price_per_day_usd > 0),
                rating REAL NOT NULL CHECK (rating >= 0 AND rating <= 5),
                verified INTEGER NOT NULL CHECK (verified IN (0, 1)),
                is_demo INTEGER NOT NULL DEFAULT 1 CHECK (is_demo = 1)
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS bookings (
                id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                guide_id TEXT NOT NULL REFERENCES guides(id),
                start_date TEXT NOT NULL,
                days INTEGER NOT NULL CHECK (days BETWEEN 1 AND 30),
                amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
                currency TEXT NOT NULL CHECK (currency = 'USD'),
                booking_status TEXT NOT NULL,
                payment_status TEXT NOT NULL,
                paypal_order_id TEXT UNIQUE,
                paypal_authorization_id TEXT,
                paypal_capture_id TEXT,
                approval_url TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        connection.executemany(
            """
            INSERT OR IGNORE INTO guides (
                id, name, city, languages_json, specialties_json,
                price_per_day_usd, rating, verified, is_demo
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
            """,
            [
                (
                    guide["id"],
                    guide["name"],
                    guide["city"],
                    json.dumps(guide["languages"]),
                    json.dumps(guide["specialties"]),
                    guide["price_per_day_usd"],
                    guide["rating"],
                    int(guide["verified"]),
                )
                for guide in DEMO_GUIDES
            ],
        )
        connection.commit()


def _serialize_guide(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "name": row["name"],
        "city": row["city"],
        "languages": json.loads(row["languages_json"]),
        "specialties": json.loads(row["specialties_json"]),
        "price_per_day_usd": row["price_per_day_usd"],
        "rating": row["rating"],
        "verified": bool(row["verified"]),
        "is_demo": bool(row["is_demo"]),
    }


def _booking_query(connection: sqlite3.Connection, booking_id: str) -> dict[str, Any] | None:
    row = connection.execute(
        """
        SELECT bookings.*, guides.name AS guide_name
        FROM bookings
        JOIN guides ON guides.id = bookings.guide_id
        WHERE bookings.id = ?
        """,
        (booking_id,),
    ).fetchone()
    return dict(row) if row else None


def get_booking(booking_id: str) -> dict[str, Any] | None:
    with closing(connect()) as connection:
        return _booking_query(connection, booking_id)


def reserve_booking(
    *,
    idempotency_key: str,
    guide_id: str,
    start_date: str,
    days: int,
) -> tuple[dict[str, Any] | None, bool]:
    """Create one pending demo booking, or return the existing idempotent one."""
    with closing(connect()) as connection:
        connection.execute("BEGIN IMMEDIATE")
        existing = connection.execute(
            "SELECT id FROM bookings WHERE idempotency_key = ?",
            (idempotency_key,),
        ).fetchone()
        if existing:
            booking = _booking_query(connection, existing["id"])
            return booking, False

        guide = connection.execute(
            """
            SELECT id, price_per_day_usd, is_demo
            FROM guides
            WHERE id = ?
            """,
            (guide_id,),
        ).fetchone()
        if not guide or not guide["is_demo"]:
            return None, False

        booking_id = uuid4().hex
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        amount_cents = int(guide["price_per_day_usd"]) * days * 100
        connection.execute(
            """
            INSERT INTO bookings (
                id, idempotency_key, guide_id, start_date, days, amount_cents,
                currency, booking_status, payment_status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, 'USD', 'payment_processing',
                'order_creating', ?, ?)
            """,
            (
                booking_id,
                idempotency_key,
                guide_id,
                start_date,
                days,
                amount_cents,
                now,
                now,
            ),
        )
        connection.commit()
        return _booking_query(connection, booking_id), True


_UNSET = object()


def transition_booking(
    booking_id: str,
    *,
    expected_states: set[tuple[str, str]],
    booking_status: str,
    payment_status: str,
    paypal_order_id: str | None | object = _UNSET,
    paypal_authorization_id: str | None | object = _UNSET,
    paypal_capture_id: str | None | object = _UNSET,
    approval_url: str | None | object = _UNSET,
) -> tuple[dict[str, Any] | None, bool]:
    """Atomically apply a booking state transition when its current state matches."""
    with closing(connect()) as connection:
        connection.execute("BEGIN IMMEDIATE")
        current = _booking_query(connection, booking_id)
        if current is None:
            return None, False
        current_state = (current["booking_status"], current["payment_status"])
        if current_state not in expected_states:
            return current, False

        updates: dict[str, Any] = {
            "booking_status": booking_status,
            "payment_status": payment_status,
            "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }
        for field, value in (
            ("paypal_order_id", paypal_order_id),
            ("paypal_authorization_id", paypal_authorization_id),
            ("paypal_capture_id", paypal_capture_id),
            ("approval_url", approval_url),
        ):
            if value is not _UNSET:
                updates[field] = value
        assignments = ", ".join(f"{field} = ?" for field in updates)
        connection.execute(
            f"UPDATE bookings SET {assignments} WHERE id = ?",
            (*updates.values(), booking_id),
        )
        connection.commit()
        return _booking_query(connection, booking_id), True


def list_guides(
    city: str | None = None,
    specialty: str | None = None,
    search: str | None = None,
) -> list[dict[str, Any]]:
    clauses: list[str] = []
    parameters: list[str] = []

    if city and city.strip():
        clauses.append("lower(city) = lower(?)")
        parameters.append(city.strip())
    if specialty and specialty.strip():
        clauses.append("lower(specialties_json) LIKE lower(?)")
        parameters.append(f'%"{specialty.strip()}"%')
    if search and search.strip():
        clauses.append(
            "("
            "lower(name) LIKE lower(?) OR "
            "lower(city) LIKE lower(?) OR "
            "lower(languages_json) LIKE lower(?) OR "
            "lower(specialties_json) LIKE lower(?)"
            ")"
        )
        search_term = f"%{search.strip()}%"
        parameters.extend([search_term] * 4)

    query = "SELECT * FROM guides"
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY city, name"

    with closing(connect()) as connection:
        rows = connection.execute(query, parameters).fetchall()
    return [_serialize_guide(row) for row in rows]


def get_guide_summary() -> dict[str, Any]:
    with closing(connect()) as connection:
        total_guides = connection.execute(
            "SELECT COUNT(*) AS count FROM guides"
        ).fetchone()["count"]
        verified_guides = connection.execute(
            "SELECT COUNT(*) AS count FROM guides WHERE verified = 1"
        ).fetchone()["count"]
        destinations = connection.execute(
            """
            SELECT city, COUNT(*) AS guide_count
            FROM guides
            GROUP BY city
            ORDER BY city
            """
        ).fetchall()

    return {
        "total_guides": total_guides,
        "verified_guides": verified_guides,
        "destination_count": len(destinations),
        "destinations": [
            {"city": row["city"], "guide_count": row["guide_count"]}
            for row in destinations
        ],
    }
